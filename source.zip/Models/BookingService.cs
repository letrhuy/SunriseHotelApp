﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SunriseHotelApp.Models
{
    public partial class BookingService
    {
        [Key]
        public int BookingServiceID { get; set; } // Khóa chính mới

        public int BookingId { get; set; } // Thuộc về đơn đặt phòng nào

        public int ProductId { get; set; } // Món gì (Bia, Nước...) - Thay cho ServiceId cũ

        public int Quantity { get; set; } // Số lượng

        public decimal PriceAtOrder { get; set; } // Giá tại thời điểm gọi

        public DateTime OrderDate { get; set; } // Thời gian gọi

        // Quan hệ (Navigation Properties)
        public virtual Booking Booking { get; set; }
        public virtual Product Product { get; set; } // Liên kết với bảng Product
    }
}