﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SunriseHotelApp.Models;

namespace SunriseHotelApp.Controllers
{
    public class DashboardController : Controller
    {
        private readonly HotelManagementDbContext _context;

        public DashboardController(HotelManagementDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // 1. Kiểm tra đăng nhập (Bắt buộc là quản lý/nhân viên)
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserName")))
            {
                return RedirectToAction("Login", "Account");
            }

            var today = DateTime.Today;

            // ==========================================
            // TÍNH TOÁN SỐ LIỆU THỐNG KÊ (KPIs)
            // ==========================================

            // A. Doanh thu ngày hôm nay (Chỉ tính đơn đã thanh toán 'Completed')
            // ĐÃ SỬA: Xóa bỏ ép kiểu và dấu ?? 0m vì TotalAmount đã chuẩn decimal
            var dailyRevenue = await _context.Bookings
                .Where(b => b.BookingStatus == "Completed" && b.CheckOutDate.Date == today)
                .SumAsync(b => b.TotalAmount);

            // B. Đếm số phòng đang có khách (Occupied)
            var occupiedCount = await _context.Rooms.CountAsync(r => r.RoomStatus == "Occupied");
            var totalRooms = await _context.Rooms.CountAsync();

            // C. Cảnh báo kho (Những món có tồn kho <= mức tối thiểu)
            var lowStockCount = await _context.Products.CountAsync(p => p.CurrentStock <= p.MinStockLevel);

            // ==========================================
            // GỬI DỮ LIỆU SANG VIEW
            // ==========================================
            ViewBag.DailyRevenue = dailyRevenue;
            ViewBag.OccupiedCount = occupiedCount;
            ViewBag.TotalRooms = totalRooms;
            ViewBag.LowStockCount = lowStockCount;

            // Lấy thêm tên người dùng để hiển thị "Chào mừng..."
            ViewBag.UserName = HttpContext.Session.GetString("FullName") ?? HttpContext.Session.GetString("UserName");

            return View();
        }

        // ==========================================
        // API LẤY DANH SÁCH THÔNG BÁO CHƯA ĐỌC
        // ==========================================
        [HttpGet]
        public async Task<IActionResult> GetUnreadNotifications()
        {
            // Lấy 5 thông báo mới nhất chưa đọc
            var notifications = await _context.Notifications
                .Where(n => n.IsRead == false)
                .OrderByDescending(n => n.CreatedAt)
                .Take(5)
                .Select(n => new {
                    id = n.Id,
                    title = n.Title,
                    message = n.Message,
                    time = n.CreatedAt.ToString("dd/MM HH:mm"),
                    type = n.Type
                })
                .ToListAsync();

            return Json(notifications);
        }

        // API Đánh dấu đã đọc
        [HttpPost]
        public async Task<IActionResult> MarkAsRead(int id)
        {
            var notif = await _context.Notifications.FindAsync(id);
            if (notif != null)
            {
                notif.IsRead = true;
                await _context.SaveChangesAsync();
            }
            return Ok();
        }

        // ==========================================
        // TÍNH NĂNG: BÁO CÁO DOANH THU CÓ LỌC NGÀY
        // ==========================================
        [HttpGet]
        public async Task<IActionResult> RevenueReport(DateTime? fromDate, DateTime? toDate)
        {
            // Bắt đầu với tất cả các đơn đặt phòng đã thanh toán xong
            var query = _context.Bookings
                .Include(b => b.Customer)
                .Include(b => b.Room)
                .Where(b => b.PaymentStatus == "Paid" || b.BookingStatus == "Completed")
                .AsQueryable();

            // Nếu người dùng có chọn ngày bắt đầu lọc
            if (fromDate.HasValue)
            {
                query = query.Where(b => b.CheckOutDate.Date >= fromDate.Value.Date);
            }
            // Nếu người dùng có chọn ngày kết thúc lọc
            if (toDate.HasValue)
            {
                query = query.Where(b => b.CheckOutDate.Date <= toDate.Value.Date);
            }

            // Thực thi truy vấn và sắp xếp mới nhất lên đầu
            var bookings = await query.OrderByDescending(b => b.CheckOutDate).ToListAsync();

            // Trả lại ngày đã chọn ra View để giữ giá trị trên ô input
            ViewBag.FromDate = fromDate?.ToString("yyyy-MM-dd");
            ViewBag.ToDate = toDate?.ToString("yyyy-MM-dd");

            // ĐÃ SỬA LỖI Ở ĐÂY: Bỏ đoạn "?? 0m" vì FinalAmount đã là kiểu decimal an toàn
            ViewBag.TotalRevenue = bookings.Sum(b => b.FinalAmount);

            return View(bookings);
        }
    }
}