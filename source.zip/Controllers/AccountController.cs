﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SunriseHotelApp.Models;

namespace SunriseHotelApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly HotelManagementDbContext _context;

        public AccountController(HotelManagementDbContext context)
        {
            _context = context;
        }

        // 1. HIỂN THỊ TRANG LOGIN
        [HttpGet]
        public IActionResult Login()
        {
            // Kiểm tra Session "UserName" (Viết hoa chữ N cho khớp với DashboardController)
            if (HttpContext.Session.GetString("UserName") != null)
            {
                // Nếu đã đăng nhập -> Vào trang Tổng quan (Dashboard/Index)
                return RedirectToAction("Index", "Dashboard");
            }
            return View();
        }

        // 2. XỬ LÝ ĐĂNG NHẬP
        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            // Tìm user: Khớp Username, Password và Tài khoản phải đang Hoạt động (IsActive == true)
            var user = await _context.SystemUsers
                .FirstOrDefaultAsync(u => u.Username == username && u.PasswordHash == password && u.IsActive == true);

            if (user != null)
            {
                // A. Lưu thông tin vào Session
                // LƯU Ý: Key phải là "UserName" (giống bên DashboardController kiểm tra)
                HttpContext.Session.SetString("UserName", user.Username);
                HttpContext.Session.SetString("Role", user.UserRole ?? "Staff");
                HttpContext.Session.SetString("FullName", user.FullName ?? "Nhân viên");

                // B. Điều hướng về TRANG TỔNG QUAN (Dashboard/Index)
                // (Code cũ của bạn đang trỏ về Sơ đồ phòng Bookings/Dashboard -> Tôi đã sửa lại)
                return RedirectToAction("Index", "Dashboard");
            }

            // Đăng nhập thất bại
            ViewBag.Error = "Sai tài khoản, mật khẩu hoặc tài khoản đã bị khóa!";
            return View();
        }

        // 3. ĐĂNG XUẤT
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}